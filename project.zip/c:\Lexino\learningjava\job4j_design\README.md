[![Build Status](https://travis-ci.org/ainz713/job4j_design.svg?branch=master)](https://travis-ci.org/ainz713/job4j_design)
[![codecov](https://codecov.io/gh/ainz713/job4j_design/branch/master/graph/badge.svg?token=6GCARE3R9I)](https://codecov.io/gh/ainz713/job4j_design)
# job4j_design